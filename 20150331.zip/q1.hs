Em java, temos uma classe para lidar com o polimorfismo, a classe Generics, que é mais geral 
que em haskell, que acaba restringindo os tipos, mas também é mais facil ocorrer erros pois 
só é verificado os tipos em tempo de execução. Em Haskell os tipos são como uma interface para
implementações para outros tipos como Num, Ord ou Eq, as vantagens de usar essas classes em 
haskell é que você poderá garantir que aquela implementação funcionará para todos os tipos
da classe (a interface em java) pois, se contrario, ocorrerá erro em tempo de compilação. 