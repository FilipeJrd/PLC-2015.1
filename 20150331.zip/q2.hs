size :: [t] -> Int -- retorna o tamanho da lista
size [] = 0
size (x:xs) = (size xs) + 1

say :: [Char] -> [Char]
say [] = []
say (x:xs) = show (size (first)) ++ [x] ++ say second
 where
 	(first, second) = (takeWhile (==x) (x:xs), dropWhile (==x) (x:xs))

fullSequence :: [Char] -> [[Char]]
fullSequence n = [said] ++ fullSequence said
 where
 	said = say n

lookAndSay :: Int -> [Char]
lookAndSay 1 = "1"
lookAndSay n = (fullSequence "1")!!(n - 2)