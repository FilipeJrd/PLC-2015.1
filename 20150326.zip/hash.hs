type Hash = [(Int, Int)]

get :: Hash -> Int -> Int
get [] key = -1
get ((k,v):xs) key
	| k == key = v
	| otherwise = get xs key

put :: Hash -> Int -> Int -> Hash
put [] key val = [(key, val)]
put ((k,v):xs) key val
	| k /= key = (k,v) : put xs key val
	| otherwise = (k,v) : xs

remove :: Hash -> Int -> Hash
remove [] key = []
remove ((k,v):xs) key
	| k == key = xs
	| otherwise = (k,v) : remove as key

hasKey:: Hash -> Int -> Bool
hasKey [] key = False
hasKey ((k,v):xs) key
	| k == key = True
	| otherwise hasKey xs key