contains :: (Eq t) => [t] -> [t] -> Bool
contains x y
	| x == [] = True
	| otherwise = ( exists y (head x) && contains (tail x) y) 

exists :: (Eq t) => [t] -> t -> Bool
exists xs e
	| xs == [] = False
	| head xs == e = True
	| otherwise = exists (tail xs) e

intersect :: (Eq t) => [t] -> [t] -> Bool
intersect xs ys
	| xs == [] = False
	| exists ys (head xs) = True
	| otherwise = intersect (tail xs) ys


comparaConjuntos :: (Eq t) => [t] -> [t] -> String
comparaConjuntos x y
	| contains x y && contains y x = "A igual a B"
	| contains x y = "B contem A"
	| contains y x = "A contem B"
	| intersect x y = "A interseciona B"
	| otherwise = "Conjuntos Disjuntos"